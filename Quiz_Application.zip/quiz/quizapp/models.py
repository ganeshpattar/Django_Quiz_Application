from django.contrib.auth.models import User
from django.db import models
import datetime


# Create your models here.

class Course(models.Model):
    course_name = models.CharField(max_length=100)

    def __str__(self):
        return self.course_name

    def get_all_course_by_id(course_id):
        return Course.objects.filter(Course=course_id)


class Question(models.Model):
    course = models.ForeignKey(Course, on_delete=models.CASCADE)
    question = models.CharField(max_length=100)
    answer = models.IntegerField()
    option_one = models.CharField(max_length=100)
    option_two = models.CharField(max_length=100)
    option_three = models.CharField(max_length=100)
    option_four = models.CharField(max_length=100)

    marks = models.IntegerField(default=1)

    def __str__(self):
        return self.question


class ScoreBoard(models.Model):
    course = models.ForeignKey(Course, on_delete=models.CASCADE)
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    date = models.DateTimeField(default=datetime.datetime.now)
    score = models.IntegerField()

    def __str__(self):
        return self.user.first_name

    @staticmethod
    def get_user_by_email(email, user):
        try:
            return user.objects.get(email)
        except:
            return False
