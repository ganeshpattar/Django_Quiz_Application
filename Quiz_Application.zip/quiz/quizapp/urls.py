from django.contrib import admin
from django.urls import path
from .views import *

urlpatterns = [
    path('', home, name="home"),
    path('test.html', test, name="test"),
    path('api/check_score', check_score, name="check_score"),
    path('<id>', take_quiz, name='take_quiz'),
    path('api/<id>', api_question, name='api_question')

]

