from django.apps import AppConfig


class QuizappdemoConfig(AppConfig):
    name = 'quizappdemo'
