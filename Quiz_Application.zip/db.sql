UPDATE quizapp_question SET marks=1;
